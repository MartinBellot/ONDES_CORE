/**
 * Instagram Demo - Ondes.Social Integration
 * Demonstrates full social features using the Ondes bridge
 */

// App State
const state = {
    currentUser: null,
    feed: [],
    stories: [],
    currentStory: null,
    currentStoryIndex: 0,
    storyTimer: null,
    selectedMedia: [],
    loading: true
};

// DOM Elements
const elements = {
    feedContainer: document.getElementById('feed-container'),
    feedPosts: document.getElementById('feed-posts'),
    feedLoading: document.getElementById('feed-loading'),
    feedEmpty: document.getElementById('feed-empty'),
    storiesScroll: document.querySelector('.stories-scroll'),
    createPostModal: document.getElementById('create-post-modal'),
    storyViewer: document.getElementById('story-viewer'),
    commentsModal: document.getElementById('comments-modal'),
    navAvatar: document.getElementById('nav-avatar')
};

// Initialize app when Ondes bridge is ready
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await initializeApp();
    } catch (error) {
        console.error('Failed to initialize app:', error);
        showError('Failed to load. Please check your connection.');
    }
});

async function initializeApp() {
    // Get current user profile
    state.currentUser = await Ondes.Social.getProfile();
    
    // Update nav avatar
    if (state.currentUser && state.currentUser.profile_picture) {
        elements.navAvatar.src = state.currentUser.profile_picture;
    }
    
    // Load feed and stories in parallel
    await Promise.all([
        loadFeed(),
        loadStories()
    ]);
    
    state.loading = false;
}

// ==================== FEED ====================

async function loadFeed() {
    try {
        elements.feedLoading.classList.remove('hidden');
        elements.feedEmpty.classList.add('hidden');
        
        const response = await Ondes.Social.getFeed({ limit: 20 });
        state.feed = response.posts || response;
        
        elements.feedLoading.classList.add('hidden');
        
        if (state.feed.length === 0) {
            elements.feedEmpty.classList.remove('hidden');
        } else {
            renderFeed();
        }
    } catch (error) {
        console.error('Error loading feed:', error);
        elements.feedLoading.classList.add('hidden');
        showError('Failed to load feed');
    }
}

function renderFeed() {
    elements.feedPosts.innerHTML = '';
    
    state.feed.forEach(post => {
        const postElement = createPostElement(post);
        elements.feedPosts.appendChild(postElement);
    });
}

function createPostElement(post) {
    const article = document.createElement('article');
    article.className = 'post-card';
    article.dataset.postId = post.uuid;
    
    // Format time
    const timeAgo = formatTimeAgo(new Date(post.created_at));
    
    // Media content
    let mediaHTML = '';
    if (post.media && post.media.length > 0) {
        if (post.media.length === 1) {
            mediaHTML = createSingleMediaHTML(post.media[0]);
        } else {
            mediaHTML = createCarouselHTML(post.media);
        }
    }
    
    // Tags
    let tagsHTML = '';
    if (post.tags && post.tags.length > 0) {
        tagsHTML = `<div class="post-tags">${post.tags.map(t => '#' + t).join(' ')}</div>`;
    }
    
    article.innerHTML = `
        <header class="post-header">
            <img class="post-avatar" src="${post.author.profile_picture || 'https://via.placeholder.com/36'}" alt="${post.author.username}">
            <div class="post-user-info">
                <div class="post-username">${post.author.username}</div>
                ${post.location ? `<div class="post-location">${post.location}</div>` : ''}
            </div>
            <button class="post-options-btn" onclick="showPostOptions('${post.uuid}')">•••</button>
        </header>
        
        <div class="post-media" ondblclick="handleDoubleTap(event, '${post.uuid}')">
            ${mediaHTML}
            <div class="double-tap-heart">
                <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
            </div>
        </div>
        
        <div class="post-actions">
            <button class="action-btn ${post.user_has_liked ? 'liked' : ''}" onclick="toggleLike('${post.uuid}')">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                </svg>
            </button>
            <button class="action-btn" onclick="showComments('${post.uuid}')">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
            </button>
            <button class="action-btn" onclick="sharePost('${post.uuid}')">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
            </button>
            <button class="action-btn bookmark-btn ${post.user_has_bookmarked ? 'bookmarked' : ''}" onclick="toggleBookmark('${post.uuid}')">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                </svg>
            </button>
        </div>
        
        <div class="post-likes">${formatLikes(post.likes_count)} likes</div>
        
        <div class="post-caption">
            <span class="username">${post.author.username}</span> ${post.content || ''}
        </div>
        
        ${tagsHTML}
        
        ${post.comments_count > 0 ? `
            <div class="post-comments-link" onclick="showComments('${post.uuid}')">
                View all ${post.comments_count} comments
            </div>
        ` : ''}
        
        <div class="post-time">${timeAgo}</div>
    `;
    
    return article;
}

function createSingleMediaHTML(media) {
    if (media.media_type === 'video') {
        // Use HLS if available
        const videoSrc = media.hls_playlist || media.compressed_file || media.original_file;
        return `
            <div class="hls-video-container">
                <video id="video-${media.uuid}" data-hls="${media.hls_playlist || ''}" 
                       src="${media.compressed_file || media.original_file}"
                       poster="${media.thumbnail}"
                       playsinline muted loop></video>
            </div>
        `;
    } else {
        return `<img src="${media.compressed_file || media.original_file}" alt="">`;
    }
}

function createCarouselHTML(mediaItems) {
    const items = mediaItems.map((media, index) => {
        const content = media.media_type === 'video' 
            ? `<video src="${media.compressed_file || media.original_file}" playsinline muted loop></video>`
            : `<img src="${media.compressed_file || media.original_file}" alt="">`;
        return `<div class="media-carousel-item">${content}</div>`;
    }).join('');
    
    const dots = mediaItems.map((_, index) => 
        `<div class="media-dot ${index === 0 ? 'active' : ''}"></div>`
    ).join('');
    
    return `
        <div class="media-carousel">${items}</div>
        <div class="media-indicator">${dots}</div>
    `;
}

// ==================== STORIES ====================

async function loadStories() {
    try {
        const response = await Ondes.Social.getStories();
        state.stories = response.stories || response;
        renderStories();
    } catch (error) {
        console.error('Error loading stories:', error);
    }
}

function renderStories() {
    elements.storiesScroll.innerHTML = '';
    
    // Add "Your Story" button
    const yourStory = document.createElement('div');
    yourStory.className = 'story-item';
    yourStory.innerHTML = `
        <div class="story-ring" style="background: transparent;">
            <div class="story-avatar">
                <img src="${state.currentUser?.profile_picture || 'https://via.placeholder.com/64'}" alt="Your story">
                <div class="add-story-badge">+</div>
            </div>
        </div>
        <span class="story-username">Your story</span>
    `;
    yourStory.onclick = () => createStory();
    elements.storiesScroll.appendChild(yourStory);
    
    // Add other users' stories
    state.stories.forEach((userStory, index) => {
        const storyItem = document.createElement('div');
        storyItem.className = 'story-item';
        const hasUnviewed = userStory.stories.some(s => !s.viewed);
        
        storyItem.innerHTML = `
            <div class="story-ring ${hasUnviewed ? '' : 'viewed'}">
                <div class="story-avatar">
                    <img src="${userStory.user.profile_picture || 'https://via.placeholder.com/64'}" alt="${userStory.user.username}">
                </div>
            </div>
            <span class="story-username">${userStory.user.username}</span>
        `;
        storyItem.onclick = () => openStoryViewer(index);
        elements.storiesScroll.appendChild(storyItem);
    });
}

function openStoryViewer(userIndex) {
    if (!state.stories[userIndex]) return;
    
    state.currentStory = state.stories[userIndex];
    state.currentStoryIndex = 0;
    
    elements.storyViewer.classList.add('active');
    showCurrentStory();
}

function showCurrentStory() {
    const userStory = state.currentStory;
    const story = userStory.stories[state.currentStoryIndex];
    
    if (!story) {
        closeStoryViewer();
        return;
    }
    
    // Check if this is the user's own story
    const isOwnStory = userStory.user.id === state.currentUser?.id;
    
    // Update header info
    document.getElementById('story-viewer-avatar').src = userStory.user.profile_picture || 'https://via.placeholder.com/32';
    document.getElementById('story-viewer-username').textContent = userStory.user.username;
    document.getElementById('story-viewer-time').textContent = formatTimeAgo(new Date(story.created_at));
    
    // Update progress bars
    const progressContainer = document.getElementById('story-progress-container');
    progressContainer.innerHTML = userStory.stories.map((_, i) => `
        <div class="story-progress">
            <div class="story-progress-fill" style="width: ${i < state.currentStoryIndex ? '100%' : '0%'}"></div>
        </div>
    `).join('');
    
    // Show content
    const contentContainer = document.getElementById('story-content');
    if (story.media_type === 'video') {
        contentContainer.innerHTML = `
            <video src="${story.hls_playlist || story.media}" autoplay playsinline muted></video>
            ${isOwnStory ? `<button class="delete-story-btn" onclick="deleteCurrentStory('${story.uuid}')">🗑️</button>` : ''}
        `;
    } else {
        contentContainer.innerHTML = `
            <img src="${story.media}" alt="">
            ${isOwnStory ? `<button class="delete-story-btn" onclick="deleteCurrentStory('${story.uuid}')">🗑️</button>` : ''}
        `;
    }
    
    // Mark as viewed
    Ondes.Social.viewStory(story.uuid);
    
    // Start progress timer
    startStoryProgress();
}

async function deleteCurrentStory(storyUuid) {
    if (state.storyTimer) {
        clearInterval(state.storyTimer);
    }
    
    if (!confirm('Delete this story?')) {
        startStoryProgress();
        return;
    }
    
    try {
        await Ondes.Social.deleteStory(storyUuid);
        
        // Remove from current user's stories
        const userStoryIndex = state.stories.findIndex(s => s.user.id === state.currentUser?.id);
        if (userStoryIndex !== -1) {
            state.stories[userStoryIndex].stories = state.stories[userStoryIndex].stories.filter(s => s.uuid !== storyUuid);
            
            // If no more stories, remove user from stories list
            if (state.stories[userStoryIndex].stories.length === 0) {
                state.stories.splice(userStoryIndex, 1);
                closeStoryViewer();
                renderStories();
                showToast('Story deleted');
                return;
            }
            
            // Update current story state
            state.currentStory = state.stories[userStoryIndex];
            if (state.currentStoryIndex >= state.currentStory.stories.length) {
                state.currentStoryIndex = state.currentStory.stories.length - 1;
            }
        }
        
        showCurrentStory();
        renderStories();
        showToast('Story deleted');
    } catch (error) {
        console.error('Error deleting story:', error);
        showToast('Failed to delete story');
        startStoryProgress();
    }
}

function startStoryProgress() {
    if (state.storyTimer) {
        clearInterval(state.storyTimer);
    }
    
    const progressBars = document.querySelectorAll('.story-progress-fill');
    const currentBar = progressBars[state.currentStoryIndex];
    let progress = 0;
    const duration = 5000; // 5 seconds per story
    const interval = 50;
    
    state.storyTimer = setInterval(() => {
        progress += (interval / duration) * 100;
        currentBar.style.width = `${progress}%`;
        
        if (progress >= 100) {
            clearInterval(state.storyTimer);
            nextStory();
        }
    }, interval);
}

function nextStory() {
    const userStory = state.currentStory;
    
    if (state.currentStoryIndex < userStory.stories.length - 1) {
        state.currentStoryIndex++;
        showCurrentStory();
    } else {
        // Move to next user's stories
        const currentUserIndex = state.stories.findIndex(s => s.user.uuid === userStory.user.uuid);
        if (currentUserIndex < state.stories.length - 1) {
            state.currentStory = state.stories[currentUserIndex + 1];
            state.currentStoryIndex = 0;
            showCurrentStory();
        } else {
            closeStoryViewer();
        }
    }
}

function prevStory() {
    if (state.currentStoryIndex > 0) {
        state.currentStoryIndex--;
        showCurrentStory();
    } else {
        // Move to previous user's stories
        const currentUserIndex = state.stories.findIndex(s => s.user.uuid === state.currentStory.user.uuid);
        if (currentUserIndex > 0) {
            state.currentStory = state.stories[currentUserIndex - 1];
            state.currentStoryIndex = state.stories[currentUserIndex - 1].stories.length - 1;
            showCurrentStory();
        }
    }
}

function closeStoryViewer() {
    if (state.storyTimer) {
        clearInterval(state.storyTimer);
    }
    elements.storyViewer.classList.remove('active');
    state.currentStory = null;
}

// ==================== INTERACTIONS ====================

async function toggleLike(postUuid) {
    const post = state.feed.find(p => p.uuid === postUuid);
    if (!post) return;
    
    const postCard = document.querySelector(`.post-card[data-post-id="${postUuid}"]`);
    const likeBtn = postCard.querySelector('.action-btn');
    const likesCount = postCard.querySelector('.post-likes');
    
    try {
        if (post.user_has_liked) {
            await Ondes.Social.unlike(postUuid);
            post.user_has_liked = false;
            post.likes_count--;
            likeBtn.classList.remove('liked');
        } else {
            await Ondes.Social.like(postUuid);
            post.user_has_liked = true;
            post.likes_count++;
            likeBtn.classList.add('liked');
        }
        likesCount.textContent = formatLikes(post.likes_count) + ' likes';
    } catch (error) {
        console.error('Error toggling like:', error);
    }
}

function handleDoubleTap(event, postUuid) {
    const post = state.feed.find(p => p.uuid === postUuid);
    if (!post || post.user_has_liked) return;
    
    // Show heart animation
    const heart = event.currentTarget.querySelector('.double-tap-heart');
    heart.classList.add('animate');
    setTimeout(() => heart.classList.remove('animate'), 800);
    
    // Like the post
    toggleLike(postUuid);
}

async function toggleBookmark(postUuid) {
    const post = state.feed.find(p => p.uuid === postUuid);
    if (!post) return;
    
    const postCard = document.querySelector(`.post-card[data-post-id="${postUuid}"]`);
    const bookmarkBtn = postCard.querySelector('.bookmark-btn');
    
    try {
        if (post.user_has_bookmarked) {
            await Ondes.Social.removeBookmark(postUuid);
            post.user_has_bookmarked = false;
            bookmarkBtn.classList.remove('bookmarked');
        } else {
            await Ondes.Social.bookmark(postUuid);
            post.user_has_bookmarked = true;
            bookmarkBtn.classList.add('bookmarked');
        }
    } catch (error) {
        console.error('Error toggling bookmark:', error);
    }
}

// ==================== COMMENTS ====================

let currentCommentsPost = null;

async function showComments(postUuid) {
    currentCommentsPost = postUuid;
    elements.commentsModal.classList.add('active');
    
    const commentsList = document.getElementById('comments-list');
    commentsList.innerHTML = '<div class="feed-loading"><div class="spinner"></div></div>';
    
    try {
        const response = await Ondes.Social.getComments(postUuid);
        const comments = response.comments || response;
        
        if (comments.length === 0) {
            commentsList.innerHTML = '<p style="text-align: center; color: var(--text-secondary); padding: 40px;">No comments yet. Be the first!</p>';
        } else {
            renderComments(comments);
        }
    } catch (error) {
        console.error('Error loading comments:', error);
        commentsList.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">Failed to load comments</p>';
    }
}

function renderComments(comments) {
    const commentsList = document.getElementById('comments-list');
    commentsList.innerHTML = comments.map(comment => {
        const isOwnComment = comment.author.id === state.currentUser?.id;
        return `
            <div class="comment-item" data-comment-id="${comment.uuid}">
                <img class="comment-avatar" src="${comment.author.profile_picture || 'https://via.placeholder.com/32'}" alt="${comment.author.username}">
                <div class="comment-content">
                    <span class="comment-username">${comment.author.username}</span>
                    <p class="comment-text">${comment.content}</p>
                    <div class="comment-meta">
                        <span>${formatTimeAgo(new Date(comment.created_at))}</span>
                        <span>${comment.likes_count} likes</span>
                        <button class="comment-like-btn" onclick="likeComment('${comment.uuid}')">
                            ${comment.user_has_liked ? 'Unlike' : 'Like'}
                        </button>
                        ${isOwnComment ? `
                            <button class="comment-delete-btn" onclick="deleteComment('${comment.uuid}')">Delete</button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

async function deleteComment(commentUuid) {
    if (!confirm('Delete this comment?')) return;
    
    try {
        await Ondes.Social.deleteComment(commentUuid);
        
        // Update comment count
        const post = state.feed.find(p => p.uuid === currentCommentsPost);
        if (post) {
            post.comments_count--;
        }
        
        // Refresh comments
        showComments(currentCommentsPost);
        showToast('Comment deleted');
    } catch (error) {
        console.error('Error deleting comment:', error);
        showToast('Failed to delete comment');
    }
}

async function postComment() {
    const input = document.getElementById('comment-input');
    const content = input.value.trim();
    
    if (!content || !currentCommentsPost) return;
    
    try {
        await Ondes.Social.comment(currentCommentsPost, content);
        input.value = '';
        
        // Refresh comments
        showComments(currentCommentsPost);
        
        // Update comment count in feed
        const post = state.feed.find(p => p.uuid === currentCommentsPost);
        if (post) {
            post.comments_count++;
            const postCard = document.querySelector(`.post-card[data-post-id="${currentCommentsPost}"]`);
            const commentsLink = postCard.querySelector('.post-comments-link');
            if (commentsLink) {
                commentsLink.textContent = `View all ${post.comments_count} comments`;
            }
        }
    } catch (error) {
        console.error('Error posting comment:', error);
    }
}

async function likeComment(commentUuid) {
    try {
        await Ondes.Social.likeComment(commentUuid);
        // Refresh comments
        showComments(currentCommentsPost);
    } catch (error) {
        console.error('Error liking comment:', error);
    }
}

function closeCommentsModal() {
    elements.commentsModal.classList.remove('active');
    currentCommentsPost = null;
}

// ==================== CREATE POST ====================

function openCreatePost() {
    state.selectedMedia = [];
    updateMediaPreview();
    document.getElementById('post-caption-input').value = '';
    elements.createPostModal.classList.add('active');
}

function closeCreatePost() {
    elements.createPostModal.classList.remove('active');
    state.selectedMedia = [];
}

async function selectMedia() {
    try {
        const result = await Ondes.Social.pickMedia({ 
            multiple: true,
            maxFiles: 10,
            allowVideo: true
        });
        
        if (result && result.length > 0) {
            state.selectedMedia = result;
            updateMediaPreview();
        }
    } catch (error) {
        console.error('Error selecting media:', error);
    }
}

function updateMediaPreview() {
    const container = document.getElementById('selected-media');
    const placeholder = document.getElementById('media-placeholder');
    
    if (state.selectedMedia.length === 0) {
        placeholder.classList.remove('hidden');
        container.classList.add('hidden');
        container.innerHTML = '';
    } else {
        placeholder.classList.add('hidden');
        container.classList.remove('hidden');
        container.innerHTML = state.selectedMedia.map((media, index) => `
            <div class="media-preview-item">
                ${media.type === 'video' 
                    ? `<video src="${media.path}"></video>` 
                    : `<img src="${media.path}" alt="">`}
                <button class="remove-media-btn" onclick="removeMedia(${index})">×</button>
            </div>
        `).join('');
    }
    
    // Update post button state
    document.getElementById('submit-post-btn').disabled = state.selectedMedia.length === 0;
}

function removeMedia(index) {
    state.selectedMedia.splice(index, 1);
    updateMediaPreview();
}

async function submitPost() {
    if (state.selectedMedia.length === 0) return;
    
    const caption = document.getElementById('post-caption-input').value;
    const visibility = document.getElementById('post-visibility').value;
    const tags = document.getElementById('post-tags').value
        .split(',')
        .map(t => t.trim())
        .filter(t => t.length > 0);
    
    const submitBtn = document.getElementById('submit-post-btn');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Posting...';
    
    try {
        await Ondes.Social.publish({
            content: caption,
            media: state.selectedMedia.map(m => m.path),
            visibility: visibility,
            tags: tags
        });
        
        // Close modal and refresh feed
        closeCreatePost();
        await loadFeed();
        
        // Scroll to top to see new post
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
        console.error('Error creating post:', error);
        alert('Failed to create post. Please try again.');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Share';
    }
}

// ==================== CREATE STORY ====================

async function createStory() {
    try {
        const result = await Ondes.Social.pickMedia({ 
            multiple: false,
            allowVideo: true
        });
        
        if (result && result.length > 0) {
            const media = result[0];
            
            // Show loading indicator
            showToast('Creating story...');
            
            await Ondes.Social.createStory({
                media: media.path,
                media_type: media.type
            });
            
            // Refresh stories
            await loadStories();
            showToast('Story created!');
        }
    } catch (error) {
        console.error('Error creating story:', error);
        showToast('Failed to create story');
    }
}

// ==================== NAVIGATION ====================

let currentPage = 'home';

function navigateTo(tab) {
    // Update active state
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    event.currentTarget.classList.add('active');
    
    // Hide all pages
    document.getElementById('feedContainer').classList.add('hidden');
    document.getElementById('searchPage').classList.add('hidden');
    document.getElementById('reelsPage').classList.add('hidden');
    document.getElementById('profilePage').classList.add('hidden');
    document.querySelector('.stories-container').classList.add('hidden');
    
    currentPage = tab;
    
    // Handle navigation
    switch(tab) {
        case 'home':
            document.getElementById('feedContainer').classList.remove('hidden');
            document.querySelector('.stories-container').classList.remove('hidden');
            break;
        case 'search':
            document.getElementById('searchPage').classList.remove('hidden');
            break;
        case 'create':
            openCreatePost();
            // Show home page in background
            document.getElementById('feedContainer').classList.remove('hidden');
            document.querySelector('.stories-container').classList.remove('hidden');
            break;
        case 'reels':
            document.getElementById('reelsPage').classList.remove('hidden');
            loadReels();
            break;
        case 'profile':
            document.getElementById('profilePage').classList.remove('hidden');
            loadProfile(state.currentUser?.id);
            break;
    }
}

// ==================== SEARCH PAGE ====================

let searchTimeout = null;

function initSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            
            // Debounce search
            clearTimeout(searchTimeout);
            
            if (query.length < 2) {
                document.getElementById('searchResults').innerHTML = `
                    <div class="search-placeholder">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="11" cy="11" r="8"/>
                            <path d="m21 21-4.35-4.35"/>
                        </svg>
                        <p>Recherchez des utilisateurs par nom</p>
                    </div>
                `;
                return;
            }
            
            searchTimeout = setTimeout(() => searchUsers(query), 300);
        });
    }
}

async function searchUsers(query) {
    const resultsContainer = document.getElementById('searchResults');
    resultsContainer.innerHTML = '<div class="feed-loading"><div class="spinner"></div></div>';
    
    try {
        const results = await Ondes.Social.searchUsers(query);
        const users = results.users || results;
        
        if (users.length === 0) {
            resultsContainer.innerHTML = `
                <div class="search-placeholder">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <circle cx="11" cy="11" r="8"/>
                        <path d="m21 21-4.35-4.35"/>
                    </svg>
                    <p>Aucun utilisateur trouvé pour "${query}"</p>
                </div>
            `;
            return;
        }
        
        resultsContainer.innerHTML = users.map(user => `
            <div class="search-result-item" onclick="openUserProfile(${user.id})">
                <img class="search-avatar" src="${user.profile_picture || 'https://via.placeholder.com/50'}" alt="${user.username}">
                <div class="search-user-info">
                    <span class="search-username">${user.username}</span>
                    ${user.bio ? `<span class="search-bio">${user.bio.substring(0, 50)}${user.bio.length > 50 ? '...' : ''}</span>` : ''}
                </div>
                ${user.id !== state.currentUser?.id ? `
                    <button class="search-follow-btn ${user.is_following ? 'following' : ''}" 
                            onclick="event.stopPropagation(); toggleFollowFromSearch(${user.id}, this)">
                        ${user.is_following ? 'Abonné' : 'Suivre'}
                    </button>
                ` : ''}
            </div>
        `).join('');
    } catch (error) {
        console.error('Error searching users:', error);
        resultsContainer.innerHTML = `<p style="text-align: center; color: var(--text-secondary);">Erreur de recherche</p>`;
    }
}

async function toggleFollowFromSearch(userId, button) {
    const isFollowing = button.classList.contains('following');
    
    try {
        if (isFollowing) {
            await Ondes.Social.unfollow(userId);
            button.classList.remove('following');
            button.textContent = 'Suivre';
        } else {
            await Ondes.Social.follow(userId);
            button.classList.add('following');
            button.textContent = 'Abonné';
        }
    } catch (error) {
        console.error('Error toggling follow:', error);
    }
}

function openUserProfile(userId) {
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    document.getElementById('profileNavBtn').classList.add('active');
    
    document.getElementById('feedContainer').classList.add('hidden');
    document.getElementById('searchPage').classList.add('hidden');
    document.getElementById('reelsPage').classList.add('hidden');
    document.querySelector('.stories-container').classList.add('hidden');
    document.getElementById('profilePage').classList.remove('hidden');
    
    loadProfile(userId);
}

// ==================== PROFILE PAGE ====================

let profileState = {
    userId: null,
    isOwnProfile: false,
    currentTab: 'posts',
    posts: [],
    bookmarks: []
};

async function loadProfile(userId = null) {
    const targetUserId = userId || state.currentUser?.id;
    profileState.isOwnProfile = !userId || userId === state.currentUser?.id;
    
    try {
        // Load user profile
        const profile = await Ondes.Social.getProfile({ userId: targetUserId });
        
        // Store the actual userId from profile response
        profileState.userId = profile.id;
        
        // Update UI
        document.getElementById('profileAvatar').src = profile.profile_picture || 'https://via.placeholder.com/90';
        document.getElementById('profileUsername').textContent = profile.username;
        document.getElementById('profileBio').textContent = profile.bio || '';
        document.getElementById('postsCount').textContent = profile.posts_count || 0;
        document.getElementById('followersCount').textContent = profile.followers_count || 0;
        document.getElementById('followingCount').textContent = profile.following_count || 0;
        
        // Update action button
        const actionsContainer = document.getElementById('profileActions');
        if (profileState.isOwnProfile) {
            actionsContainer.innerHTML = `
                <button class="profile-btn" onclick="editProfile()">Modifier le profil</button>
            `;
        } else {
            actionsContainer.innerHTML = `
                <button class="profile-btn ${profile.is_following ? 'following' : 'primary'}" onclick="toggleProfileFollow()">
                    ${profile.is_following ? 'Abonné' : 'Suivre'}
                </button>
            `;
        }
        
        // Show/hide bookmarks tab (only for own profile)
        const bookmarksTab = document.querySelector('.profile-tab[data-tab="bookmarks"]');
        if (bookmarksTab) {
            bookmarksTab.style.display = profileState.isOwnProfile ? 'flex' : 'none';
        }
        
        // Load posts
        await loadProfilePosts();
        
    } catch (error) {
        console.error('Error loading profile:', error);
        showToast('Erreur lors du chargement du profil');
    }
}

async function loadProfilePosts() {
    const grid = document.getElementById('profileGrid');
    grid.innerHTML = '<div class="feed-loading"><div class="spinner"></div></div>';
    
    try {
        const response = await Ondes.Social.getUserPosts(profileState.userId);
        profileState.posts = response.posts || response;
        
        renderProfileGrid(profileState.posts);
    } catch (error) {
        console.error('Error loading posts:', error);
        grid.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">Erreur de chargement</p>';
    }
}

async function loadProfileBookmarks() {
    const grid = document.getElementById('profileGrid');
    grid.innerHTML = '<div class="feed-loading"><div class="spinner"></div></div>';
    
    try {
        const response = await Ondes.Social.getBookmarks();
        profileState.bookmarks = response.posts || response;
        
        renderProfileGrid(profileState.bookmarks);
    } catch (error) {
        console.error('Error loading bookmarks:', error);
        grid.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">Erreur de chargement</p>';
    }
}

function renderProfileGrid(posts) {
    const grid = document.getElementById('profileGrid');
    
    if (posts.length === 0) {
        grid.innerHTML = `
            <div class="profile-empty">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <rect x="3" y="3" width="18" height="18" rx="2"/>
                </svg>
                <p>Aucun post</p>
            </div>
        `;
        return;
    }
    
    grid.innerHTML = posts.map(post => {
        const media = post.media?.[0];
        const thumbnail = media?.thumbnail || media?.compressed_file || media?.original_file || 'https://via.placeholder.com/150';
        const isVideo = media?.media_type === 'video';
        
        return `
            <div class="profile-grid-item" onclick="openPostFromProfile('${post.uuid}')">
                <img src="${thumbnail}" alt="">
                ${isVideo ? `
                    <div class="grid-video-icon">
                        <svg viewBox="0 0 24 24" fill="white">
                            <polygon points="5 3 19 12 5 21 5 3"/>
                        </svg>
                    </div>
                ` : ''}
                ${post.media?.length > 1 ? `
                    <div class="grid-multi-icon">
                        <svg viewBox="0 0 24 24" fill="white">
                            <rect x="2" y="6" width="16" height="12" rx="2"/>
                            <rect x="6" y="2" width="16" height="12" rx="2"/>
                        </svg>
                    </div>
                ` : ''}
            </div>
        `;
    }).join('');
}

function switchProfileTab(tab) {
    profileState.currentTab = tab;
    
    document.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.profile-tab[data-tab="${tab}"]`).classList.add('active');
    
    if (tab === 'posts') {
        loadProfilePosts();
    } else if (tab === 'bookmarks') {
        loadProfileBookmarks();
    }
}

async function toggleProfileFollow() {
    const btn = document.querySelector('#profileActions .profile-btn');
    const isFollowing = btn.classList.contains('following');
    
    try {
        if (isFollowing) {
            await Ondes.Social.unfollow(profileState.userId);
            btn.classList.remove('following');
            btn.classList.add('primary');
            btn.textContent = 'Suivre';
            
            const count = parseInt(document.getElementById('followersCount').textContent) - 1;
            document.getElementById('followersCount').textContent = count;
        } else {
            await Ondes.Social.follow(profileState.userId);
            btn.classList.add('following');
            btn.classList.remove('primary');
            btn.textContent = 'Abonné';
            
            const count = parseInt(document.getElementById('followersCount').textContent) + 1;
            document.getElementById('followersCount').textContent = count;
        }
    } catch (error) {
        console.error('Error toggling follow:', error);
        showToast('Erreur');
    }
}

async function showFollowers() {
    document.getElementById('usersModalTitle').textContent = 'Followers';
    document.getElementById('usersModal').classList.add('active');
    
    const listContainer = document.getElementById('usersList');
    listContainer.innerHTML = '<div class="feed-loading"><div class="spinner"></div></div>';
    
    try {
        const response = await Ondes.Social.getFollowers(profileState.userId);
        const users = response.followers || response;
        renderUsersList(users);
    } catch (error) {
        console.error('Error loading followers:', error);
        listContainer.innerHTML = '<p style="text-align: center;">Erreur de chargement</p>';
    }
}

async function showFollowing() {
    document.getElementById('usersModalTitle').textContent = 'Abonnements';
    document.getElementById('usersModal').classList.add('active');
    
    const listContainer = document.getElementById('usersList');
    listContainer.innerHTML = '<div class="feed-loading"><div class="spinner"></div></div>';
    
    try {
        const response = await Ondes.Social.getFollowing(profileState.userId);
        const users = response.following || response;
        renderUsersList(users);
    } catch (error) {
        console.error('Error loading following:', error);
        listContainer.innerHTML = '<p style="text-align: center;">Erreur de chargement</p>';
    }
}

function renderUsersList(users) {
    const listContainer = document.getElementById('usersList');
    
    if (users.length === 0) {
        listContainer.innerHTML = '<p style="text-align: center; padding: 20px;">Aucun utilisateur</p>';
        return;
    }
    
    listContainer.innerHTML = users.map(user => `
        <div class="user-item" onclick="closeUsersModal(); openUserProfile(${user.id})">
            <img class="user-avatar" src="${user.profile_picture || 'https://via.placeholder.com/40'}" alt="${user.username}">
            <span class="user-name">${user.username}</span>
        </div>
    `).join('');
}

function closeUsersModal() {
    document.getElementById('usersModal').classList.remove('active');
}

function openPostFromProfile(postUuid) {
    // Find post in either posts or bookmarks
    const post = profileState.posts.find(p => p.uuid === postUuid) || 
                 profileState.bookmarks.find(p => p.uuid === postUuid);
    
    if (post) {
        // Navigate to home and scroll to post or show in modal
        showToast('Affichage du post');
        // For now, just show the feed with this post
        state.feed = [post];
        document.getElementById('profilePage').classList.add('hidden');
        document.getElementById('feedContainer').classList.remove('hidden');
        document.querySelector('.stories-container').classList.remove('hidden');
        renderFeed();
    }
}

function editProfile() {
    showToast('Modification du profil - bientôt disponible');
}

// ==================== REELS PAGE ====================

let reelsState = {
    videos: [],
    currentIndex: 0
};

async function loadReels() {
    const container = document.getElementById('reelsContainer');
    container.innerHTML = '<div class="reels-loading"><div class="spinner"></div></div>';
    
    try {
        const response = await Ondes.Social.getFeed({
            media_type: 'video',
            limit: 20
        });
        
        reelsState.videos = (response.posts || response).filter(post => 
            post.media && post.media.some(m => m.media_type === 'video')
        );
        
        if (reelsState.videos.length === 0) {
            container.innerHTML = `
                <div class="reels-empty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <rect x="2" y="2" width="20" height="20" rx="2"/>
                        <path d="m10 8 6 4-6 4V8z"/>
                    </svg>
                    <h3>Aucun Reel</h3>
                    <p>Les vidéos apparaîtront ici</p>
                </div>
            `;
            return;
        }
        
        renderReels();
    } catch (error) {
        console.error('Error loading reels:', error);
        container.innerHTML = '<p style="text-align: center; color: white; padding: 40px;">Erreur de chargement</p>';
    }
}

function renderReels() {
    const container = document.getElementById('reelsContainer');
    container.innerHTML = '';
    
    reelsState.videos.forEach((post, index) => {
        const videoMedia = post.media.find(m => m.media_type === 'video');
        const videoSrc = videoMedia.hls_playlist || videoMedia.compressed_file || videoMedia.original_file;
        
        const reelItem = document.createElement('div');
        reelItem.className = 'reel-item';
        reelItem.innerHTML = `
            <video 
                id="reel-video-${index}"
                src="${videoSrc}"
                poster="${videoMedia.thumbnail || ''}"
                playsinline
                loop
                muted
            ></video>
            
            <div class="reel-info">
                <div class="reel-author" onclick="openUserProfile(${post.author.id})">
                    <img src="${post.author.profile_picture || 'https://via.placeholder.com/32'}" alt="">
                    <span>${post.author.username}</span>
                </div>
                <p class="reel-caption">${post.content || ''}</p>
            </div>
            
            <div class="reel-actions">
                <button class="reel-action ${post.user_has_liked ? 'liked' : ''}" onclick="toggleReelLike('${post.uuid}', ${index})">
                    <svg viewBox="0 0 24 24" fill="${post.user_has_liked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                    </svg>
                    <span>${formatLikes(post.likes_count)}</span>
                </button>
                <button class="reel-action" onclick="showComments('${post.uuid}')">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                    </svg>
                    <span>${post.comments_count}</span>
                </button>
                <button class="reel-action ${post.user_has_bookmarked ? 'bookmarked' : ''}" onclick="toggleReelBookmark('${post.uuid}', ${index})">
                    <svg viewBox="0 0 24 24" fill="${post.user_has_bookmarked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                    </svg>
                </button>
            </div>
        `;
        
        container.appendChild(reelItem);
    });
    
    // Setup scroll observer for reels
    setupReelsObserver();
}

function setupReelsObserver() {
    const reelItems = document.querySelectorAll('.reel-item');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            const video = entry.target.querySelector('video');
            if (entry.isIntersecting) {
                video.play().catch(() => {});
            } else {
                video.pause();
            }
        });
    }, { threshold: 0.5 });
    
    reelItems.forEach(item => observer.observe(item));
}

async function toggleReelLike(postUuid, index) {
    const post = reelsState.videos[index];
    if (!post) return;
    
    const btn = document.querySelector(`.reel-item:nth-child(${index + 1}) .reel-action.liked, .reel-item:nth-child(${index + 1}) .reel-action:first-child`);
    
    try {
        if (post.user_has_liked) {
            await Ondes.Social.unlikePost(postUuid);
            post.user_has_liked = false;
            post.likes_count--;
        } else {
            await Ondes.Social.likePost(postUuid);
            post.user_has_liked = true;
            post.likes_count++;
        }
        
        // Re-render this reel
        renderReels();
    } catch (error) {
        console.error('Error toggling reel like:', error);
    }
}

async function toggleReelBookmark(postUuid, index) {
    const post = reelsState.videos[index];
    if (!post) return;
    
    try {
        if (post.user_has_bookmarked) {
            await Ondes.Social.unbookmarkPost(postUuid);
            post.user_has_bookmarked = false;
        } else {
            await Ondes.Social.bookmarkPost(postUuid);
            post.user_has_bookmarked = true;
        }
        
        renderReels();
    } catch (error) {
        console.error('Error toggling reel bookmark:', error);
    }
}

// ==================== POST OPTIONS ====================

let currentOptionsPost = null;

function showPostOptions(postUuid) {
    currentOptionsPost = postUuid;
    const post = state.feed.find(p => p.uuid === postUuid);
    
    const modal = document.getElementById('postOptionsModal');
    const content = modal.querySelector('.options-content');
    
    // Show different options based on ownership
    if (post && post.author.id === state.currentUser?.id) {
        content.innerHTML = `
            <button class="option-item danger" onclick="deleteCurrentPost()">Supprimer</button>
            <button class="option-item" onclick="copyPostLink()">Copier le lien</button>
            <button class="option-item" onclick="closePostOptions()">Annuler</button>
        `;
    } else {
        content.innerHTML = `
            <button class="option-item" onclick="copyPostLink()">Copier le lien</button>
            <button class="option-item" onclick="reportPost()">Signaler</button>
            <button class="option-item" onclick="closePostOptions()">Annuler</button>
        `;
    }
    
    modal.classList.add('active');
}

async function deleteCurrentPost() {
    if (!currentOptionsPost) return;
    
    if (!confirm('Voulez-vous vraiment supprimer ce post ?')) {
        closePostOptions();
        return;
    }
    
    try {
        await Ondes.Social.deletePost(currentOptionsPost);
        
        // Remove from feed
        state.feed = state.feed.filter(p => p.uuid !== currentOptionsPost);
        renderFeed();
        
        showToast('Post supprimé');
        closePostOptions();
    } catch (error) {
        console.error('Error deleting post:', error);
        showToast('Erreur lors de la suppression');
    }
}

function copyPostLink() {
    const link = `ondes://social/post/${currentOptionsPost}`;
    navigator.clipboard?.writeText(link).then(() => {
        showToast('Lien copié');
    }).catch(() => {
        showToast('Impossible de copier');
    });
    closePostOptions();
}

function reportPost() {
    showToast('Signalement envoyé');
    closePostOptions();
}

function closePostOptions() {
    document.getElementById('postOptionsModal').classList.remove('active');
    currentOptionsPost = null;
}

async function sharePost(postUuid) {
    try {
        await Ondes.Utils.share({
            title: 'Check out this post!',
            url: `ondes://social/post/${postUuid}`
        });
    } catch (error) {
        console.error('Error sharing:', error);
    }
}

// ==================== UTILITIES ====================

function formatTimeAgo(date) {
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatLikes(count) {
    if (count >= 1000000) return (count / 1000000).toFixed(1) + 'M';
    if (count >= 1000) return (count / 1000).toFixed(1) + 'K';
    return count.toString();
}

function showToast(message) {
    // Simple toast notification
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        bottom: 90px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--bg-card);
        color: var(--text-primary);
        padding: 12px 24px;
        border-radius: 8px;
        z-index: 1000;
        animation: fadeInOut 2s ease forwards;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.remove(), 2000);
}

function showError(message) {
    elements.feedLoading.classList.add('hidden');
    elements.feedPosts.innerHTML = `
        <div class="feed-empty">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
            <h3>Oops!</h3>
            <p>${message}</p>
        </div>
    `;
}

// Add CSS animation for toast
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInOut {
        0%, 100% { opacity: 0; }
        20%, 80% { opacity: 1; }
    }
`;
document.head.appendChild(style);

// Initialize HLS.js for video playback if needed
function initHlsPlayer(videoElement) {
    const hlsUrl = videoElement.dataset.hls;
    if (!hlsUrl) return;
    
    if (Hls.isSupported()) {
        const hls = new Hls({
            maxBufferLength: 30,
            maxMaxBufferLength: 60
        });
        hls.loadSource(hlsUrl);
        hls.attachMedia(videoElement);
    } else if (videoElement.canPlayType('application/vnd.apple.mpegurl')) {
        // Native HLS support (Safari)
        videoElement.src = hlsUrl;
    }
}

// Intersection Observer for video autoplay
const videoObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        const video = entry.target;
        if (entry.isIntersecting) {
            video.play().catch(() => {});
        } else {
            video.pause();
        }
    });
}, { threshold: 0.5 });

// Observe videos when they are added to the DOM
const feedObserver = new MutationObserver((mutations) => {
    mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1) {
                const videos = node.querySelectorAll ? node.querySelectorAll('video') : [];
                videos.forEach(video => {
                    initHlsPlayer(video);
                    videoObserver.observe(video);
                });
            }
        });
    });
});

feedObserver.observe(document.body, { childList: true, subtree: true });

// Pull to refresh
let touchStartY = 0;
let isPulling = false;

document.addEventListener('touchstart', (e) => {
    if (window.scrollY === 0) {
        touchStartY = e.touches[0].clientY;
        isPulling = true;
    }
});

document.addEventListener('touchmove', (e) => {
    if (!isPulling) return;
    
    const touchY = e.touches[0].clientY;
    const diff = touchY - touchStartY;
    
    if (diff > 100 && window.scrollY === 0) {
        // Visual feedback could be added here
    }
});

document.addEventListener('touchend', async (e) => {
    if (!isPulling) return;
    
    const touchY = e.changedTouches[0].clientY;
    const diff = touchY - touchStartY;
    
    if (diff > 100 && window.scrollY === 0) {
        showToast('Refreshing...');
        await Promise.all([loadFeed(), loadStories()]);
    }
    
    isPulling = false;
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeCreatePost();
        closeCommentsModal();
        closeStoryViewer();
    }
});

// Handle comment input Enter key
document.getElementById('comment-input')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        postComment();
    }
});

// Initialize search functionality
initSearch();

// Nav button click handlers
document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const tab = btn.dataset.tab;
        if (tab) navigateTo(tab);
    });
});

// Make sure feedContainer has default state (not hidden)
document.getElementById('feedContainer').classList.remove('hidden');
document.querySelector('.stories-container')?.classList.remove('hidden');
